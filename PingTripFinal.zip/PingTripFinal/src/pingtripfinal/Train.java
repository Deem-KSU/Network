
package com.mycompany.pingtrip;
import java.util.ArrayList;

public class Train {
    private String id;
    private String source;
    private String destination;
    private ArrayList<Ticket> tickets = new ArrayList<>();

    public Train(String id, String source, String destination) {
        this.id = id;
        this.source = source;
        this.destination = destination;
        generateTickets();
    }

    private void generateTickets() {
        
        for (int day = 1; day <= 7; day++) {
            
            for (int i = 1; i <= 4; i++) {
                String tid = id + "-D" + day + "-F" + i;
                tickets.add(new Ticket(tid, id, "first", day));
            }
           
            for (int i = 1; i <= 4; i++) {
                String tid = id + "-D" + day + "-E" + i;
                tickets.add(new Ticket(tid, id, "economy", day));
            }
        }
    }
    

    public String getId() { return id; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public ArrayList<Ticket> getTickets() { return tickets; }
}