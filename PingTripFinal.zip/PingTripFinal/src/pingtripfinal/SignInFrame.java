
package com.mycompany.pingtrip;
import javax.swing.*; 
import java.awt.*; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.io.*; 
import java.net.Socket; 

public class SignInFrame extends JFrame {
   
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton signupSubmitButton;
    private JLabel statusLabel;
    private ClientConnection client; 

    public SignInFrame() {
        
        setTitle("Sign up"); 
        setSize(400, 300); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLocationRelativeTo(null); 

        setLayout(new BorderLayout()); 

        
        JLabel welcomeLabel = new JLabel("WELCOME !", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(welcomeLabel, BorderLayout.NORTH);

       
        JPanel formPanel = new JPanel(new GridBagLayout()); 
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 
        
        
        gbc.gridx = 0; 
        gbc.gridy = 0; 
        gbc.weightx = 0; 
        JLabel usernameLabel = new JLabel("Username:", SwingConstants.RIGHT); 
        formPanel.add(usernameLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 0;
        gbc.weightx = 1.0; 
        usernameField = new JTextField(15);
        usernameField.setPreferredSize(new Dimension(150, 25)); 
        formPanel.add(usernameField, gbc);
        
        
        gbc.gridx = 0; 
        gbc.gridy = 1; 
        gbc.weightx = 0;
        JLabel passwordLabel = new JLabel("Password:", SwingConstants.RIGHT);
        formPanel.add(passwordLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 1;
        gbc.weightx = 1.0; 
        passwordField = new JPasswordField(15); 
        passwordField.setPreferredSize(new Dimension(150, 25));
        formPanel.add(passwordField, gbc);
        
        add(formPanel, BorderLayout.CENTER); 
        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        
        JPanel buttonContainer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        signupSubmitButton = new JButton("Sign Up");
        signupSubmitButton.setPreferredSize(new Dimension(150, 30));
        


        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0)); 
        
        buttonContainer.add(signupSubmitButton); 
        
        JButton backButton = new JButton("Back");
        buttonContainer.add(backButton);
        
        statusLabel = new JLabel("", SwingConstants.CENTER); 
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 15, 0));
        
        bottomPanel.add(buttonContainer, BorderLayout.NORTH);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);
        
        add(bottomPanel, BorderLayout.SOUTH); 

       
        signupSubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptSignIn(); 
            }
        });
        
        backButton.addActionListener(e -> {
            new WelcomeFrame().setVisible(true);
            dispose();
});

    }

    
    private void attemptSignIn() {
    String username = usernameField.getText();
    char[] password = passwordField.getPassword();

    new SwingWorker<String, Void>() {
        @Override
        protected String doInBackground() throws Exception {

            statusLabel.setText("Connecting to server...");
            signupSubmitButton.setEnabled(false);

            try {
                client = new ClientConnection("localhost", 1234);

                
                String cmd = "SIGNUP " + username + " " + new String(password);
                return client.sendAndReceive(cmd);

            } catch (IOException e) {
                return "CONNECTION_FAILED";
            }
        }

        @Override
protected void done() {
    signupSubmitButton.setEnabled(true);
    try {
        String response = get();

        if ("SIGNUP_SUCCESS".equals(response)) {
            statusLabel.setText("Account created!");
            statusLabel.setForeground(Color.GREEN.darker());

            JOptionPane.showMessageDialog(SignInFrame.this,
                    "You have registered successfully, Hello (" + username + ")");

            new MainMenuFrame(client).setVisible(true);
            dispose();

        } else if (response.startsWith("SIGNUP_FAILED")) {
            statusLabel.setForeground(Color.RED);
            statusLabel.setText("Username already exists!");
            
        } else if ("CONNECTION_FAILED".equals(response)) {
            statusLabel.setForeground(Color.RED);
            statusLabel.setText("Cannot reach server!");
        }

    } catch (Exception ex) {
        statusLabel.setText("Unexpected error");
        statusLabel.setForeground(Color.RED);
    }
}

    }.execute();
}}
