package com.mycompany.pingtrip;

import javax.swing.*;
import java.awt.*;

public class MyReservationsFrame extends JFrame {

    private ClientConnection client;
    private DefaultListModel<String> reservationsModel;
    private JList<String> reservationsList;
    private JButton cancelButton, backButton;
    private JLabel statusLabel;

    public MyReservationsFrame(ClientConnection client) {
        this.client = client;

        setTitle("My Reservations");
        setSize(450, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

       
        JLabel title = new JLabel("My Reservations", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(title, BorderLayout.NORTH);

       
        reservationsModel = new DefaultListModel<>();
        reservationsList = new JList<>(reservationsModel);
        reservationsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(reservationsList), BorderLayout.CENTER);

        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());

        cancelButton = new JButton("Cancel Reservation");
        cancelButton.setEnabled(false);
        backButton = new JButton("Back");

        buttonPanel.add(cancelButton);
        buttonPanel.add(backButton);

        statusLabel = new JLabel("Select a reservation to cancel", SwingConstants.CENTER);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        
        reservationsList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cancelButton.setEnabled(reservationsList.getSelectedIndex() != -1);
            }
        });

        cancelButton.addActionListener(e -> cancelSelectedReservation());

        backButton.addActionListener(e -> {
            new MainMenuFrame(client).setVisible(true);
            dispose();
        });

        loadReservations();
        setVisible(true);
    }

    
    private void loadReservations() {
        reservationsModel.clear();
        statusLabel.setText("Loading reservations...");

        new SwingWorker<String, Void>() {

            @Override
            protected String doInBackground() throws Exception {
                client.sendCommand("MYRES");
                return client.receiveReservationsResponse(); 
            }

            @Override
            protected void done() {
                try {
                    String response = get();

                    if (response == null || response.isBlank()) {
                        statusLabel.setText("You have no reservations.");
                        return;
                    }

                    
                    String[] lines = response.split("\n");
                    for (String line : lines) {
                        if (line.trim().startsWith("T")) {
                            reservationsModel.addElement(line.trim());
                        }
                    }

                    if (reservationsModel.isEmpty()) {
                        statusLabel.setText("You have no reservations.");
                    } else {
                        statusLabel.setText("Select a reservation to cancel");
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    statusLabel.setText("Failed to load reservations.");
                }
            }
        }.execute();
    }

    
    private void cancelSelectedReservation() {
        String selected = reservationsList.getSelectedValue();

        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a reservation to cancel",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ticketId = selected.split(" ")[0];
        statusLabel.setText("Canceling " + ticketId + "...");
        cancelButton.setEnabled(false);

        new SwingWorker<String, Void>() {

            @Override
            protected String doInBackground() throws Exception {
                return client.sendCommand("CANCEL " + ticketId);
            }

            @Override
            protected void done() {
                try {
                    String response = get();

                    if (response != null && response.contains("CANCEL_SUCCESS")) {
                        JOptionPane.showMessageDialog(MyReservationsFrame.this,
                                "Reservation canceled successfully!");
                        loadReservations();
                    } else {
                        JOptionPane.showMessageDialog(MyReservationsFrame.this,
                                "Failed to cancel reservation.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(MyReservationsFrame.this,
                            "Error during cancellation.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }
}
