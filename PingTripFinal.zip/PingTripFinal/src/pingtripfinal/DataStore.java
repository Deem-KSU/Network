package com.mycompany.pingtrip;

import java.io.*;
import java.util.ArrayList;

public class DataStore {

    private static final String USERS_FILE = "users.txt";
    private static final String RESERVATIONS_FILE = "reservations.txt";

    public static void loadData(ArrayList<User> users, TrainManager manager) {
        loadUsers(users);
        loadReservations(users, manager);
    }

    public static void saveUsers(ArrayList<User> users) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(USERS_FILE))) {
            for (User u : users) {
                pw.println(u.getUsername() + "," + u.getPassword());
            }
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    public static void saveReservations(ArrayList<User> users) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RESERVATIONS_FILE))) {
            for (User u : users) {
                for (String tid : u.getReservations()) {
                    pw.println(u.getUsername() + "," + tid);
                }
            }
        } catch (IOException e) {
            System.err.println("Error saving reservations: " + e.getMessage());
        }
    }

    private static void loadUsers(ArrayList<User> users) {
        File f = new File(USERS_FILE);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String password = parts[1].trim();
                    users.add(new User(username, password));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
    }

    private static void loadReservations(ArrayList<User> users, TrainManager manager) {
        File f = new File(RESERVATIONS_FILE);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String ticketId = parts[1].trim();

                    User u = findUser(users, username);
                    if (u != null) {
                        u.addReservation(ticketId);
                        manager.reserveTicket(ticketId); 
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading reservations: " + e.getMessage());
        }
    }

    private static User findUser(ArrayList<User> users, String username) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return u;
            }
        }
        return null;
    }
}
