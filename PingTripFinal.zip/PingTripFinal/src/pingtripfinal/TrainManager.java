
package com.mycompany.pingtrip;
import java.util.ArrayList;

public class TrainManager {
    private ArrayList<Train> trains = new ArrayList<>();

    public TrainManager() {
        initializeTrains();
    }

    private void initializeTrains() {
        trains.add(new Train("T1", "Riyadh", "Dammam"));
        trains.add(new Train("T2", "Riyadh", "Jeddah"));
        trains.add(new Train("T3", "Riyadh", "Mecca"));
        trains.add(new Train("T4", "Mecca", "Medina"));
        trains.add(new Train("T5", "Dammam", "Jeddah"));
      
    }

   
    public ArrayList<Ticket> findAvailableTickets(String source, String destination, int day, String classType) {
        ArrayList<Ticket> available = new ArrayList<>();
        for (Train t : trains) {
            if (t.getSource().equalsIgnoreCase(source) && t.getDestination().equalsIgnoreCase(destination)) {
                for (Ticket ticket : t.getTickets()) {
                    if (ticket.getDay() == day && 
                        ticket.getClassType().equalsIgnoreCase(classType) &&
                        !ticket.isReserved()) {
                        available.add(ticket);
                    }
                }
            }
        }
        return available;
    }

    
    public synchronized boolean reserveTicket(String ticketId) {
        for (Train t : trains) {
            for (Ticket ticket : t.getTickets()) {
                if (ticket.getTicketId().equalsIgnoreCase(ticketId)) {
                    if (!ticket.isReserved()) {
                        ticket.reserve();
                        return true;
                    }
                    return false;
                }
            }
        }
        return false;
    }
    
    public synchronized boolean cancelTicket(String ticketId) {
        for (Train t : trains) {
            for (Ticket ticket : t.getTickets()) {
                if (ticket.getTicketId().equalsIgnoreCase(ticketId)) {
                    if (ticket.isReserved()) {
                        ticket.unreserve();
                        return true;
                    }
                    return false; 
                }
            }
        }
        return false;
    }
}