package com.mycompany.pingtrip;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel statusLabel;
    private ClientConnection client;

    public LoginFrame() {

        setTitle("Log In");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        
        JLabel title = new JLabel("LOGIN", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(title, BorderLayout.NORTH);

       
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel usernameLabel = new JLabel("Username:");
        formPanel.add(usernameLabel, gbc);

       
        gbc.gridx = 1;
        usernameField = new JTextField(15);
        usernameField.setPreferredSize(new Dimension(150, 25));
        formPanel.add(usernameField, gbc);

       
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passwordLabel = new JLabel("Password:");
        formPanel.add(passwordLabel, gbc);

        
        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        passwordField.setPreferredSize(new Dimension(150, 25));
        formPanel.add(passwordField, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());

        JPanel buttonContainer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(150, 30)); 
        buttonContainer.add(loginButton);
        
        JButton backButton = new JButton("Back");
        buttonContainer.add(backButton);

        backButton.addActionListener(e -> {
        new WelcomeFrame().setVisible(true);
        dispose();
        });


        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        bottomPanel.add(buttonContainer, BorderLayout.NORTH);

        
        statusLabel = new JLabel("", SwingConstants.CENTER);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        
        loginButton.addActionListener(e -> attemptLogin());

        setVisible(true);
    }

    private void attemptLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                statusLabel.setText("Connecting...");
                loginButton.setEnabled(false);

                try {
                    client = new ClientConnection("localhost", 1234);
                    String cmd = "LOGIN " + username + " " + password;
                    return client.sendAndReceive(cmd);

                } catch (Exception ex) {
                    return "CONNECTION_FAILED";
                }
            }

            @Override
            protected void done() {
                loginButton.setEnabled(true);
                try {
                    String response = get();

                    if ("LOGIN_SUCCESS".equals(response)) {
                        JOptionPane.showMessageDialog(LoginFrame.this,
                                "Welcome back " + username + "!");
                        new MainMenuFrame(client).setVisible(true);
                        dispose();

                    } else if (response.startsWith("LOGIN_FAILED")) {
                        statusLabel.setForeground(Color.RED);
                        statusLabel.setText("Wrong username or password!");

                    } else {
                        statusLabel.setForeground(Color.RED);
                        statusLabel.setText("Connection failed!");
                    }

                } catch (Exception e) {
                    statusLabel.setText("Unexpected error");
                }
            }

        }.execute();
    }
}
