package com.mycompany.pingtrip;

import java.io.*;
import java.net.Socket;

public class ClientConnection {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    public ClientConnection(String host, int port) throws IOException {
        this.socket = new Socket(host, port);
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        System.out.println("Server Welcome: " + in.readLine());
        System.out.println("Server Commands: " + in.readLine());
    }

    
    public String sendAndReceive(String msg) throws IOException {
        out.println(msg);
        return in.readLine(); 
    }

    
    public String receiveMultiLineResponse() throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;

        while ((line = in.readLine()) != null) {

            
            if (line.trim().isEmpty()) {
                break;
            }

            sb.append(line).append("\n");

           
            if (line.startsWith("No available tickets")) {
                break;
            }
        }

        return sb.toString().trim();
    }

    
    public String receiveReservationsResponse() throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;

        while ((line = in.readLine()) != null) {

            if (line.trim().isEmpty()) {
                break;
            }

            sb.append(line).append("\n");

            if (line.startsWith("You have no reservations")) {
                break;
            }
        }

        return sb.toString().trim();
    }

    
    public String sendCommand(String command) throws IOException {
        out.println(command);

        if (command.startsWith("RESERVE") || command.startsWith("CANCEL")) {
            return in.readLine();  
        }

        return null; 
    }

    public void close() throws IOException {
        if (socket != null && !socket.isClosed()) {
            socket.close();
        }
    }
}
