package com.mycompany.pingtrip;

import javax.swing.*;
import java.awt.*;

public class WelcomeFrame extends JFrame {
    private JButton loginButton;
    private JButton signupButton;
    private JPanel mainPanel;

    public WelcomeFrame() {

        setTitle("PingTrip System");
        setSize(350, 350); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome aboard PingTrip!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(15, 10, 5, 10));
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

     
        ImageIcon icon = new ImageIcon("PingTripLogo.png");

        Image scaled = icon.getImage().getScaledInstance(140, 140, Image.SCALE_SMOOTH);
        JLabel imageLabel = new JLabel(new ImageIcon(scaled));
        imageLabel.setAlignmentX(CENTER_ALIGNMENT);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        centerPanel.add(imageLabel);

        centerPanel.add(Box.createVerticalStrut(10));

        JPanel buttonContainer = new JPanel();
        buttonContainer.setLayout(new BoxLayout(buttonContainer, BoxLayout.Y_AXIS));

        buttonContainer.add(Box.createVerticalStrut(10));

        loginButton = new JButton("Log In");
        loginButton.setAlignmentX(CENTER_ALIGNMENT);
        loginButton.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
        buttonContainer.add(loginButton);

        buttonContainer.add(Box.createVerticalStrut(10));

        signupButton = new JButton("Sign Up");
        signupButton.setAlignmentX(CENTER_ALIGNMENT);
        signupButton.addActionListener(e -> {
            new SignInFrame().setVisible(true);
            dispose();
        });
        buttonContainer.add(signupButton);

        buttonContainer.add(Box.createVerticalStrut(10));

        centerPanel.add(buttonContainer);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);
    }
}
