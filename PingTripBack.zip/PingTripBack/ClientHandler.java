package com.mycompany.pingtrip;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class ClientHandler implements Runnable {

    private Socket client;
    private BufferedReader in;
    private PrintWriter out;
    private TrainManager manager;

    private static ArrayList<User> users = new ArrayList<>();

    private String currentUser = null;

    public ClientHandler(Socket client, TrainManager manager) throws IOException {
        this.client = client;
        this.manager = manager;
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true);
    }

    @Override
    public void run() {
        try {
            out.println("Welcome to Train Reservation System!");
            out.println(
                "Commands: SIGNUP <u> <p> | LOGIN <u> <p> | " +
                "FIND <source> <destination> <day> <classType> | " +
                "RESERVE <ticketId> | MYRES | CANCEL <ticketId> | EXIT"
            );

            String line;
            while ((line = in.readLine()) != null) {

                line = line.trim();
                if (line.equalsIgnoreCase("exit")) {
                    out.println("Goodbye!");
                    break;
                }

                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s+");
                String command = parts[0].toUpperCase();

                switch (command) {

                  
                    case "SIGNUP":
                        if (parts.length != 3) {
                            out.println("SIGNUP_FAILED Invalid format");
                        } else {
                            String uName = parts[1];
                            String p = parts[2];

                            boolean exists = false;
                            for (User usr : users) {
                                if (usr.getUsername().equalsIgnoreCase(uName)) {
                                    exists = true;
                                    break;
                                }
                            }

                            if (exists) {
                                out.println("SIGNUP_FAILED Username exists");
                            } else {
                                users.add(new User(uName, p));
                                currentUser = uName;
                                out.println("SIGNUP_SUCCESS");
                            }
                        }
                        break;

                    
                    case "LOGIN":
                        if (parts.length != 3) {
                            out.println("LOGIN_FAILED Invalid format");
                        } else {
                            String uName = parts[1];
                            String p = parts[2];

                            boolean ok = false;
                            for (User usr : users) {
                                if (usr.getUsername().equalsIgnoreCase(uName)
                                        && usr.getPassword().equals(p)) {
                                    ok = true;
                                    currentUser = uName;
                                    break;
                                }
                            }

                            if (ok) {
                                out.println("LOGIN_SUCCESS");
                            } else {
                                out.println("LOGIN_FAILED Wrong username or password");
                            }
                        }
                        break;

                   
                    case "FIND":
                        if (parts.length != 5) {
                            out.println("Usage: FIND <source> <destination> <day> <classType>");
                        } else {
                            String source = parts[1];
                            String destination = parts[2];
                            int day = Integer.parseInt(parts[3]);
                            String classType = parts[4];
                            ArrayList<Ticket> found =
                                    manager.findAvailableTickets(source, destination, day, classType);
                            if (found.isEmpty()) {
                                out.println("No available tickets found.");
                            } else {
                                out.println("Available tickets:");
                                for (Ticket t : found) {
                                    out.println(t.toString());
                                }
                                out.println("");
                            }
                        }
                        break;

                    
                    case "RESERVE":
                        if (parts.length != 2) {
                            out.println("Usage: RESERVE <ticketId>");
                        } else {
                            String ticketId = parts[1];
                            boolean success = manager.reserveTicket(ticketId);
                            if (success) {
                                
                                User u = getCurrentUserObject();
                                if (u != null) {
                                    u.addReservation(ticketId);
                                }
                                out.println("Ticket " + ticketId + " reserved successfully!");
                            } else {
                                out.println("Failed to reserve ticket (already reserved or not found).");
                            }
                        }
                        break;

                    
                    case "MYRES": {
                        User u = getCurrentUserObject();
                        if (u == null) {
                            out.println("ERROR You are not logged in.");
                            break;
                        }

                        ArrayList<String> res = u.getReservations();
                        if (res.isEmpty()) {
                            out.println("You have no reservations.");
                        } else {
                            out.println("Your reservations:");
                            for (String tid : res) {
                                out.println(tid);
                            }
                            out.println("");
                        }
                        break;
                    }

                    
                    case "CANCEL": {
                        if (parts.length != 2) {
                            out.println("Usage: CANCEL <ticketId>");
                            break;
                        }

                        User u = getCurrentUserObject();
                        if (u == null) {
                            out.println("ERROR You are not logged in.");
                            break;
                        }

                        String ticketId = parts[1];

                        boolean cancelled = manager.cancelTicket(ticketId);
                        if (cancelled) {
                            u.removeReservation(ticketId);
                            out.println("CANCEL_SUCCESS Ticket " + ticketId + " canceled.");
                        } else {
                            out.println("CANCEL_FAILED Ticket not reserved or not found.");
                        }
                        break;
                    }

                    
                    default:
                        out.println("Unknown command.");
                }
            }

        } catch (IOException e) {
            System.out.println("Client disconnected: " + client.getInetAddress());
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    
    private User getCurrentUserObject() {
        if (currentUser == null) return null;
        for (User usr : users) {
            if (usr.getUsername().equalsIgnoreCase(currentUser)) {
                return usr;
            }
        }
        return null;
    }
}
