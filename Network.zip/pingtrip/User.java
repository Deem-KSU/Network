package com.mycompany.pingtrip;

import java.util.ArrayList;

public class User {
    private String username;
    private String password;
    private ArrayList<String> reservations = new ArrayList<>();

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // إضافة حجز للمستخدم
    public void addReservation(String ticketId) {
        if (!reservations.contains(ticketId)) {
            reservations.add(ticketId);
        }
    }

    // حذف حجز من المستخدم
    public void removeReservation(String ticketId) {
        reservations.remove(ticketId);
    }

    // إرجاع قائمة حجوزات المستخدم
    public ArrayList<String> getReservations() {
        return new ArrayList<>(reservations);
    }
}
