package com.mycompany.pingtrip;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class MainMenuFrame extends JFrame {

    private JButton newTicketButton;
    private JButton myReservationsButton;
    private JButton exitButton;

    private ClientConnection client;

    public MainMenuFrame(ClientConnection client) {
        this.client = client;

        setTitle("Main Menu");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

       
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

       
        JLabel welcomeLabel = new JLabel("Welcome to PingTrip System!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setAlignmentX(CENTER_ALIGNMENT);
        panel.add(welcomeLabel);

        panel.add(Box.createVerticalStrut(25));

       
        Dimension buttonSize = new Dimension(200, 40);

       
        newTicketButton = new JButton("Book New Ticket");
        newTicketButton.setPreferredSize(buttonSize);
        newTicketButton.setMaximumSize(buttonSize);
        newTicketButton.setAlignmentX(CENTER_ALIGNMENT);

        newTicketButton.addActionListener(e -> {
            new ReservationFrame(client).setVisible(true);
            dispose();
        });

        panel.add(newTicketButton);
        panel.add(Box.createVerticalStrut(15));

        
        myReservationsButton = new JButton("My Reservations");
        myReservationsButton.setPreferredSize(buttonSize);
        myReservationsButton.setMaximumSize(buttonSize);
        myReservationsButton.setAlignmentX(CENTER_ALIGNMENT);

        myReservationsButton.addActionListener(e -> {
            new MyReservationsFrame(client).setVisible(true);
            dispose();
        });

        panel.add(myReservationsButton);
        panel.add(Box.createVerticalStrut(15));

        
        exitButton = new JButton("Exit");
        exitButton.setPreferredSize(buttonSize);
        exitButton.setMaximumSize(buttonSize);
        exitButton.setAlignmentX(CENTER_ALIGNMENT);

        exitButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to exit?",
                    "Exit",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    client.sendCommand("EXIT");
                    client.close();
                } catch (IOException ex) {
                    System.err.println("Error closing connection: " + ex.getMessage());
                }
                System.exit(0);
            }
        });

        panel.add(exitButton);

        add(panel);
        setVisible(true);
    }
}
