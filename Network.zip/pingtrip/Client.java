package com.mycompany.pingtrip;
import javax.swing.SwingUtilities;

public class Client {
    
    
    public static void main(String[] args) {
      
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                new WelcomeFrame().setVisible(true);
            }
        });
    }
}