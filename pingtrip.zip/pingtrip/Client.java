/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pingtrip;
import javax.swing.SwingUtilities;

public class Client {
    
    
    public static void main(String[] args) {
      
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                new WelcomeFrame().setVisible(true);
            }
        });
    }
}